document.addEventListener('DOMContentLoaded', () => {
    const board = document.getElementById('board');
    const message = document.querySelector('.message');
    const turnMessage = document.getElementById('turnMessage');
    const endScreen = document.getElementById('endScreen');
    const endMessage = document.getElementById('endMessage');
    const playerWinsSpan = document.getElementById('playerWins');
    const playerLossesSpan = document.getElementById('playerLosses');
    const restartContainer = document.getElementById('restartContainer');
    let currentPlayer = 'X';
    let gameBoard = ['', '', '', '', '', '', '', '', ''];
    let gameActive = true;
    let playerWins = 0;
    let playerLosses = 0;

    function renderBoard() {
        board.innerHTML = '';
        gameBoard.forEach((value, index) => {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            cell.textContent = value;
            cell.addEventListener('click', () => handleCellClick(index));
            board.appendChild(cell);
        });
    }

    function handleCellClick(index) {
        if (!gameActive || gameBoard[index] !== '') return;

        gameBoard[index] = currentPlayer;
        renderBoard();
        checkWinner();
        togglePlayer();
    }

    function togglePlayer() {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        updateTurnMessage();
    }

    function updateTurnMessage() {
        turnMessage.textContent = `Player ${currentPlayer}'s turn`;
    }

    function checkWinner() {
        const winPatterns = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
            [0, 4, 8], [2, 4, 6]             // Diagonals
        ];

        for (const pattern of winPatterns) {
            const [a, b, c] = pattern;
            if (gameBoard[a] && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
                gameActive = false;
                playerWins++;
                updateEndScreen(`Player ${currentPlayer} wins!`);
                updateScore();
                return;
            }
        }

        if (!gameBoard.includes('')) {
            gameActive = false;
            playerLosses++;
            updateEndScreen('It\'s a draw!');
            updateScore();
        }
    }

    function updateScore() {
        playerWinsSpan.textContent = playerWins;
        playerLossesSpan.textContent = playerLosses;
    }

    function updateEndScreen(msg) {
        endMessage.textContent = msg;
        endScreen.style.display = 'flex';
    }

    window.startNewGame = function () {
        gameBoard = ['', '', '', '', '', '', '', '', ''];
        gameActive = true;
        renderBoard();
        endScreen.style.display = 'none';
        updateTurnMessage();
    };

    window.restartGame = function () {
        gameBoard = ['', '', '', '', '', '', '', '', ''];
        gameActive = true;
        renderBoard();
        endScreen.style.display = 'none';
        updateTurnMessage();
    };

    renderBoard();
    updateTurnMessage();
    updateScore();
});
